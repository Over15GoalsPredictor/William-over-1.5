plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

dependencies { implementation("androidx.work:work-runtime-ktx:2.10.0") }
android {
    namespace = "com.example.over15"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.over15"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
