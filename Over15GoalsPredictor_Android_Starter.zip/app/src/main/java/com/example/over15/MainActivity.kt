package com.example.over15

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.work.*
import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

data class Pick(val home:String, val away:String, val league:String, val kickoff:String, val probability:Int, val note:String)


class DailyScanWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val prefs=applicationContext.getSharedPreferences("over15", Context.MODE_PRIVATE)
        val key=prefs.getString("key","") ?: ""
        if(key.isBlank()) return Result.failure()
        return try {
            val date=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
            val conn=URL("https://v3.football.api-sports.io/fixtures?date=$date&timezone=Africa%2FJohannesburg").openConnection() as HttpURLConnection
            conn.setRequestProperty("x-apisports-key",key)
            val json=JSONObject(conn.inputStream.bufferedReader().use { it.readText() }); conn.disconnect()
            val count=json.optJSONArray("response")?.length() ?: 0
            prefs.edit().putString("daily_scan_date",date).putInt("daily_fixture_count",count).apply()
            Result.success()
        } catch (_:Exception) { Result.retry() }
    }
}

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var apiKey: EditText
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private val prefs by lazy { getSharedPreferences("over15", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scheduleDailyScan()
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,24,24,24); setBackgroundColor(0xFF10251B.toInt()) }
        val title = TextView(this).apply { text="OVER 1.5 GOALS"; textSize=25f; setTextColor(0xFFFFFFFF.toInt()); gravity=Gravity.CENTER; setPadding(0,12,0,4) }
        val subtitle = TextView(this).apply { text="Daily football scanner • 90%+ filter"; textSize=14f; setTextColor(0xFFB9D8C6.toInt()); gravity=Gravity.CENTER; setPadding(0,0,0,20) }
        apiKey = EditText(this).apply { hint="Enter your API-Football key"; setSingleLine(true); setText(prefs.getString("key","") ?: ""); setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFB9D8C6.toInt()) }
        val save = Button(this).apply { text="Save API key" ; setOnClickListener { prefs.edit().putString("key",apiKey.text.toString().trim()).apply(); scheduleDailyScan(); toast("API key saved; daily refresh scheduled") } }
        val scan = Button(this).apply { text="SCAN TODAY'S FIXTURES"; setOnClickListener { scanFixtures() } }
        status = TextView(this).apply { text="Add your API key, then scan today's fixtures."; setTextColor(0xFFFFFFFF.toInt()); textSize=14f; setPadding(0,16,0,16) }
        results = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(title); root.addView(subtitle); root.addView(apiKey, lp()); root.addView(save); root.addView(scan); root.addView(status); root.addView(results)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun scheduleDailyScan() {
        val work=PeriodicWorkRequestBuilder<DailyScanWorker>(24, java.util.concurrent.TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("over15_daily_scan", ExistingPeriodicWorkPolicy.UPDATE, work)
    }
    private fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun toast(s:String) = Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun request(path:String, key:String): JSONObject {
        val c = (URL("https://v3.football.api-sports.io/$path").openConnection() as HttpURLConnection)
        c.requestMethod="GET"; c.setRequestProperty("x-apisports-key",key); c.connectTimeout=15000; c.readTimeout=20000
        try { val body=c.inputStream.bufferedReader().use { it.readText() }; return JSONObject(body) }
        finally { c.disconnect() }
    }
    private fun scanFixtures() {
        val key=apiKey.text.toString().trim()
        if(key.isBlank()){ toast("Enter an API-Football key first"); return }
        prefs.edit().putString("key",key).apply()
        status.text="Loading today's fixtures…"; results.removeAllViews()
        thread {
            try {
                val date=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
                val fixtureJson=request("fixtures?date=$date&timezone=Africa%2FJohannesburg",key)
                val arr=fixtureJson.optJSONArray("response") ?: org.json.JSONArray()
                val picks=mutableListOf<Pick>()
                for(i in 0 until arr.length()) {
                    val item=arr.getJSONObject(i); val fixture=item.getJSONObject("fixture")
                    val statusShort=fixture.getJSONObject("status").optString("short")
                    if(statusShort!="NS") continue
                    val teams=item.getJSONObject("teams")
                    val home=teams.getJSONObject("home").optString("name")
                    val away=teams.getJSONObject("away").optString("name")
                    val league=item.getJSONObject("league").optString("name")
                    val id=fixture.getInt("id")
                    try {
                        val pred=request("predictions?fixture=$id",key).optJSONArray("response")
                        if(pred==null || pred.length()==0) continue
                        val p=pred.getJSONObject(0).getJSONObject("predictions")
                        val over=p.optString("under_over","").lowercase(Locale.ROOT)
                        // API-Football gives a qualitative over/under prediction, not a calibrated probability.
                        // Do not invent a numeric probability: only include explicit Over 1.5 signals as candidates.
                        if(over.contains("over") && over.contains("1.5")) {
                            val dateTime=fixture.optString("date")
                            picks.add(Pick(home,away,league,dateTime,0,"Provider indicates Over 1.5; numeric probability not supplied"))
                        }
                    } catch (_:Exception) { }
                }
                runOnUiThread {
                    status.text="Scan complete: ${picks.size} provider Over 1.5 candidates. A verified 90%+ probability is not available from this feed."
                    if(picks.isEmpty()) addMessage("No matches returned an explicit Over 1.5 signal today.")
                    picks.forEach { p ->
                        val card=TextView(this).apply {
                            text="${p.home} vs ${p.away}\n${p.league}\n${p.kickoff}\nOver 1.5 signal — probability not provided"
                            textSize=15f; setTextColor(0xFFFFFFFF.toInt()); setPadding(16,16,16,16); setBackgroundColor(0xFF244735.toInt())
                        }
                        val params=lp(); params.setMargins(0,8,0,8); results.addView(card,params)
                    }
                }
            } catch(e:Exception) { runOnUiThread { status.text="Could not load fixtures: ${e.message}. Check your API key and connection." } }
        }
    }
    private fun addMessage(s:String) { results.addView(TextView(this).apply { text=s; textSize=14f; setTextColor(0xFFFFFFFF.toInt()); setPadding(8,16,8,16) }) }
}
